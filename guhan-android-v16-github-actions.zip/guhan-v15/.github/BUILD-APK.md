# Build G.U.H.A.N. V16 automatically

GitHub Actions is configured in `.github/workflows/build-apk.yml`.

Every push, pull request, or manual workflow run builds the Android debug APK and uploads it as the `guhan-v16-debug-apk` artifact.

The Android project is under `android/`.
